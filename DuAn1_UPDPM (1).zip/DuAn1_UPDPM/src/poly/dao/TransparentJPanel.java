/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

/**
 *
 * @author Admin
 */
public class TransparentJPanel extends JPanel {

private float panelAlfa;
private float childrenAlfa;

public TransparentJPanel(float panelAlfa, float childrenAlfa) {
       this.panelAlfa = panelAlfa;
       this.childrenAlfa = childrenAlfa;
}

@Override
public void paintComponent(Graphics g) {
       Graphics2D g2d = (Graphics2D) g;
       g2d.setColor(getBackground());
       g2d.setRenderingHint(
               RenderingHints.KEY_ANTIALIASING,
               RenderingHints.VALUE_ANTIALIAS_ON);
       g2d.setComposite(AlphaComposite.getInstance(
               AlphaComposite.SRC_OVER, panelAlfa));
       super.paintComponent(g2d);

}

@Override
protected void paintChildren(Graphics g) {
       Graphics2D g2d = (Graphics2D) g;
       g2d.setColor(getBackground());
       g2d.setRenderingHint(
               RenderingHints.KEY_ANTIALIASING,
               RenderingHints.VALUE_ANTIALIAS_ON);
       g2d.setComposite(AlphaComposite.getInstance(
               AlphaComposite.SRC_ATOP, childrenAlfa));

       super.paintChildren(g); 
}
    //getter and setter
}
