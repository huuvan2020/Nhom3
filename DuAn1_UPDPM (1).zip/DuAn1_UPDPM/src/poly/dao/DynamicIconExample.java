/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// ví dụ về một biêt tượng có sự thay đổi hình dạng
public class DynamicIconExample {

    public static void main(String[] args) {
        //Tạo ra một cặp thanh trượt để điều chỉnh kích cỡ của biểu tượng
        final JSlider width = new JSlider(JSlider.HORIZONTAL, 1, 100, 1);
        final JSlider height = new JSlider(JSlider.VERTICAL, 1, 100, 1);

        //Một lớp icon nhỏ sử dụng giá trị thanh trượt hiện tại
        class DynamicIcon implements Icon {

            public int getIconWidth() {
                return width.getValue();
            }

            public int getIconHeight() {
                return height.getValue();
            }

            public void paintIcon(Component c, Graphics g, int x, int y) {
                g.fill3DRect(x, y, getIconWidth(), getIconHeight(), true);
            }
        };
        Icon icon = new DynamicIcon();
        final JLabel dynamicLabel = new JLabel(icon);

        //Một listener để vẽ lại biểu tượng khi thanh trượt được điều chỉnh
        class Updater implements ChangeListener {

            public void stateChanged(ChangeEvent ev) {
                dynamicLabel.repaint();
            }
        };
        Updater updater = new Updater();
        width.addChangeListener(updater);
        height.addChangeListener(updater);

        //Đặt tất cả lên frame
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container c = f.getContentPane();
        c.setLayout(new BorderLayout());
        c.add(width, BorderLayout.NORTH);
        c.add(height, BorderLayout.WEST);
        c.add(dynamicLabel, BorderLayout.CENTER);

        new Timer(40, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int value = width.getValue();
                int value2 = width.getValue();
                if (value < 100) {
                    width.setValue(value + 1);
                    height.setValue(value2 + 1);
                } else {
                    width.setValue(0);
                    height.setValue(0);
                }
            }
        }).start();
        f.setSize(210, 210);
        f.setVisible(true);
    }
}
