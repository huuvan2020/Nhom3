/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Logos;

import com.helper.JdbcHelper;
import com.model.DanhGia;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class DanhGiaDAO {

    /**
     *
     * @param model dữ liệu đưa vào Thêm dữ liệu vào cơ sở dữ liệu
     */
    public void insert(DanhGia model) {
        String sql = "insert into danhGia (maNV,maCH,noiDungDanhGia) values(?,?,?)";
        JdbcHelper.executeUpdate(sql,
                model.getMaNV(),
                model.getMaCH(),
                model.getNoiDungCH());
    }

    /**
     *
     * @param model dữ liệu đưa vào Cập nhật dữ liệu
     */
    public void update(int madg,DanhGia model) {
        String sql = "update danhGia set noiDungDanhGia = ? where maDG = ?";
        JdbcHelper.executeUpdate(sql,
                model.getNoiDungCH(),
                madg);
    }

    /**
     *
     * @param madg mã đánh giá Xóa dữ liệu trong bảng đánh giá theo mã đánh giá
     */
    public void delete(int madg) {
        String sql = "delete from danhGia where maDG = ?";
        JdbcHelper.executeUpdate(sql, madg);
    }

    public int maDanhGia(String manv, int mach) {
        String sql = "select * from DanhGia where maNV = ? and maCh = ?";
        List<DanhGia> list = select(sql,manv,mach);
        return list.size() > 0 ? list.get(0).getMaDG() : null;
    }

    public DanhGia findByid(int madg) {
        String sql = "select * from DanhGia where madg = ?";
        List<DanhGia> list = select(sql, madg);
        return list.size() > 0 ? list.get(0) : null;
    }

    public List<DanhGia> select(String sql, Object... args) {
        List<DanhGia> list = new ArrayList<>();
        try {
            ResultSet rs = null;
            try {
                rs = JdbcHelper.executeQuery(sql, args);
                while (rs.next()) {
                    DanhGia model = readFromResultSet(rs);
                    list.add(model);
                }
            } finally {
                rs.getStatement().getConnection().close();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    private DanhGia readFromResultSet(ResultSet rs) throws SQLException {
        DanhGia model = new DanhGia();
        model.setMaDG(rs.getInt("maDG"));
        model.setMaNV(rs.getString("maNV"));
        model.setMaCH(rs.getInt("maCH"));
        model.setNoiDungCH(rs.getString("noiDungDanhGia"));
        return model;
    }
}
