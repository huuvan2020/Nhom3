/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Logos;

import com.helper.JdbcHelper;
import com.model.NhanVien;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class NhanVienDAO {
    public void insert(NhanVien model) {
        String sql = "insert into nhanVien (maNV,hoTen,matKhau,ngaySinh,queQuan, gioiTinh,chucVu,email,sdt,anh)"
                + "values(?,?,?,?,?,?,?,?,?,?)";
        JdbcHelper.executeUpdate(sql,
                model.getMaNV(),
                model.getHoTen(),
                model.getMaKhau(),
                model.getNgaySinh(),
                model.getQueQuan(),
                model.isGioiTinh(),
                model.getChucVu(),
                model.getEmail(),
                model.getSdt(),
                model.getAnh());
    }
    public void update(NhanVien model) {
        String sql = "update nhanVien set hoTen = ?, ngaySinh = ?,queQuan = ?,gioiTinh = ?,chucVu = ?,"
                + "email = ?, sdt = ?,anh = ? where maNV = ?";
        JdbcHelper.executeUpdate(sql, 
                model.getHoTen(),
                model.getNgaySinh(),
                model.getQueQuan(),
                model.isGioiTinh(),
                model.getChucVu(),
                model.getEmail(),
                model.getSdt(),
                model.getAnh(),
                model.getMaNV());
    }
    public void updatePassword(NhanVien model) {
        String sql = "update nhanVien set matKhau = ? where maNV = ?";
        JdbcHelper.executeUpdate(sql,
                model.getMaKhau(),
                model.getMaNV());
    }
    public void delete(String ma) {
        String sql = "delete from nhanVien where maNV = ?";
        JdbcHelper.executeUpdate(sql, ma);
    }
    /**
     * 
     * @return danh sách nhân viên + thông tin mỗi nhân viên
     */
    public List<NhanVien> select() {
        String sql = "select * from nhanVien";
        return select(sql);
    }
    /**
     * 
     * @param manv là mã nhân viên
     * @return trả về thông tin của 1 nhân viên theo manv
     */
    public NhanVien findByid(String manv) {
        String sql = "select * from NhanVien where maNV = ?";
        List<NhanVien> list = select(sql, manv);
        return list.size() > 0 ? list.get(0): null;
    }
    private List<NhanVien> select(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<>();
        try {
            ResultSet rs = null;
            try {
                rs = JdbcHelper.executeQuery(sql, args);
                while (rs.next()) {
                    NhanVien model = readFromResultSet(rs);
                    list.add(model);
                }
            } finally {
                rs.getStatement().getConnection().close();
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return list;
    }
    private NhanVien readFromResultSet(ResultSet rs) throws SQLException {
        NhanVien model = new NhanVien();
        model.setMaNV(rs.getString("maNV"));
        model.setMaKhau(rs.getString("matKhau"));
        model.setHoTen(rs.getString("hoTen"));
        model.setNgaySinh(rs.getDate("ngaySinh"));
        model.setQueQuan(rs.getString("queQuan"));
        model.setGioiTinh(rs.getBoolean("gioiTinh"));
        model.setChucVu(rs.getInt("chucVu"));
        model.setEmail(rs.getString("email"));
        model.setSdt(rs.getString("sdt"));
        model.setAnh(rs.getString("anh"));
        return model;
    }
}
