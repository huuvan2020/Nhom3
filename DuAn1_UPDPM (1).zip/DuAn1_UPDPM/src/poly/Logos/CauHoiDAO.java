/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Logos;

import com.helper.JdbcHelper;
import com.model.CauHoi;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class CauHoiDAO {
    public void insert(CauHoi model) {
        String sql = "insert into cauHoi(monHoc,lop,mucDo,maNV,cauHoiBai,cauTraLoiDung,"
                + "cauTraLoiSai1,cauTraLoiSai2,cauTraLoiSai3) values(?,?,?,?,?,?,?,?,?)";
        JdbcHelper.executeUpdate(sql,
                model.getMonHoc(),
                model.getLop(),
                model.isMucDo(),
                model.getMaNV(),
                model.getCauHoiBai(),
                model.getCauTraLoiDung(),
                model.getCauTraLoiSai1(),
                model.getCauTraLoiSai2(),
                model.getCauTraLoiSai3());
    }
    public void update(CauHoi model) {
        String sql = "update cauHoi set monHoc = ?,lop = ?, mucDo = ?,maNV = ?,cauHoiBai = ?,cauTraLoiDung = ?,"
                + "cauTraLoiSai1 = ?,cauTraLoiSai2 = ?,cauTraLoiSai3 = ? where maCH = ?";
        JdbcHelper.executeUpdate(sql,
                model.getMonHoc(),
                model.getLop(),
                model.isMucDo(),
                model.getMaNV(),
                model.getCauHoiBai(),
                model.getCauTraLoiDung(),
                model.getCauTraLoiSai1(),
                model.getCauTraLoiSai2(),
                model.getCauTraLoiSai3(),
                model.getMaCH());
    }
    public void delete(int ma) {
        String sql = "delete from cauHoi where maCH = ?";
        JdbcHelper.executeUpdate(sql, ma);
    }
    /**
     * 
     * @return danh sách câu hỏi + thông tin mỗi câu hỏi
     */
    public List<CauHoi> select() {
        String sql = "select * from cauHoi";
        return select(sql);
    }
    public CauHoi findByid(int mach) {
        String sql = "select * from CauHoi where maCH = ?";
        List<CauHoi> list = select(sql,mach);
        return list.size() > 0 ? list.get(0) : null;
    }
    private List<CauHoi> select(String sql, Object...args) {
        List<CauHoi> list = new ArrayList<>();
        try {
            ResultSet rs = null;
            try {
                rs = JdbcHelper.executeQuery(sql, args);
                while (rs.next()) {
                    CauHoi model = readFromResultSet(rs);
                    list.add(model);
                }
            }
            finally {
                rs.getStatement().getConnection().close();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    private CauHoi readFromResultSet(ResultSet rs) throws SQLException {
        CauHoi model = new CauHoi();
        model.setMaCH(rs.getInt("maCH"));
        model.setMonHoc(rs.getString("monHoc"));
        model.setLop(rs.getInt("lop"));
        model.setMucDo(rs.getBoolean("mucDo"));
        model.setMaNV(rs.getString("maNV"));
        model.setCauHoiBai(rs.getString("cauHoiBai"));
        model.setCauTraLoiDung(rs.getString("cauTraLoiDung"));
        model.setCauTraLoiSai1(rs.getString("cauTraLoiSai1"));
        model.setCauTraLoiSai2(rs.getString("cauTraLoiSai2"));
        model.setCauTraLoiSai3(rs.getString("cauTraLoiSai3"));
        return model;
    }
}
