/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

/**
 *
 * @author Admin
 */
public class CauHoi {
    private int maCH;
    private String monHoc;
    private int lop;
    private boolean mucDo;
    private String maNV;
    private String cauHoiBai;
    private String cauTraLoiDung;
    private String cauTraLoiSai1;
    private String cauTraLoiSai2;
    private String cauTraLoiSai3;

    public int getMaCH() {
        return maCH;
    }

    public String getMonHoc() {
        return monHoc;
    }

    public int getLop() {
        return lop;
    }

    public boolean isMucDo() {
        return mucDo;
    }

    public String getMaNV() {
        return maNV;
    }

    public String getCauHoiBai() {
        return cauHoiBai;
    }

    public String getCauTraLoiDung() {
        return cauTraLoiDung;
    }

    public String getCauTraLoiSai1() {
        return cauTraLoiSai1;
    }

    public String getCauTraLoiSai2() {
        return cauTraLoiSai2;
    }

    public String getCauTraLoiSai3() {
        return cauTraLoiSai3;
    }

    public void setMaCH(int maCH) {
        this.maCH = maCH;
    }

    public void setMonHoc(String monHoc) {
        this.monHoc = monHoc;
    }

    public void setLop(int lop) {
        this.lop = lop;
    }

    public void setMucDo(boolean mucDo) {
        this.mucDo = mucDo;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public void setCauHoiBai(String cauHoiBai) {
        this.cauHoiBai = cauHoiBai;
    }

    public void setCauTraLoiDung(String cauTraLoiDung) {
        this.cauTraLoiDung = cauTraLoiDung;
    }

    public void setCauTraLoiSai1(String cauHoiSai1) {
        this.cauTraLoiSai1 = cauHoiSai1;
    }

    public void setCauTraLoiSai2(String cauHoiSai2) {
        this.cauTraLoiSai2 = cauHoiSai2;
    }

    public void setCauTraLoiSai3(String cauHoiSai3) {
        this.cauTraLoiSai3 = cauHoiSai3;
    }
    
    
}
