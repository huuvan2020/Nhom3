/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

/**
 *
 * @author Admin
 */
public class DanhGia {
    private int maDG;
    private String maNV;
    private int maCH;
    private String noiDungCH;

    public int getMaDG() {
        return maDG;
    }

    public String getMaNV() {
        return maNV;
    }

    public int getMaCH() {
        return maCH;
    }

    public String getNoiDungCH() {
        return noiDungCH;
    }

    public void setMaDG(int maDG) {
        this.maDG = maDG;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public void setMaCH(int maCH) {
        this.maCH = maCH;
    }

    public void setNoiDungCH(String noiDungCH) {
        this.noiDungCH = noiDungCH;
    }

}
