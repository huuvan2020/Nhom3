/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class NhanVien {
    private String maNV;
    private String maKhau;
    private String hoTen;
    private Date ngaySinh;
    private boolean gioiTinh;
    private int chucVu;
    private String queQuan;
    private String email;
    private String sdt;
    private String anh;

    public String getMaNV() {
        return maNV;
    }

    public String getMaKhau() {
        return maKhau;
    }

    public String getHoTen() {
        return hoTen;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public int getChucVu() {
        return chucVu;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public String getEmail() {
        return email;
    }

    public String getSdt() {
        return sdt;
    }

    public String getAnh() {
        return anh;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public void setMaKhau(String maKhau) {
        this.maKhau = maKhau;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public void setChucVu(int chucVu) {
        this.chucVu = chucVu;
    }

    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public void setAnh(String anh) {
        this.anh = anh;
    }
    
    
}
